package com.ourhabit.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

// v3.3: Voice selection needs the Voice class from android.speech.tts
import android.speech.tts.Voice;

/**
 * AlarmSpeakService — v2.9: THE NAMED ALERT (owner: "আমার নাম আনোয়ারুল সন
 * সাকিব... আমাকে ডাকবে — আনোয়ারুল সন সাকিব, তোমার পানি খাওয়ার সময় হইছে,
 * পানি খাও, স্বাস্থ্য ঠিক থাকবে").
 *
 * v4.0: a PLAIN background service (NO startForeground → NO notification
 * at all — owner killed the visible "আপনাকে ডাকা হচ্ছে…" one too). It SPEAKS
 * the alert with the user's name through the Android TextToSpeech engine on
 * the ALARM audio stream — so the phone literally calls the user by name,
 * exactly like a person would. Right after the voice finishes, the real
 * alarm notification fires with its own channel sound (water music /
 * meal music / chime) → the experience is: the app CALLS you, THEN the
 * alarm rings.
 *
 * Adhan alarms NEVER use this (owner: "আজানের ক্ষেত্রে না ভাই — আজানটা আজানি
 * দিবে") — they go straight to the full-screen azan + adhan audio.
 *
 * Started by AlarmFireReceiver (alarm time) or by ExactAlarmPlugin.speakOnce
 * (in-app / background warnings e.g. Reels limit).
 */
public class AlarmSpeakService extends Service {

  public static final String EXTRA_SPEAK = "speak";
  public static final String EXTRA_SPEAK_EN = "speakEn"; // v4.1: English fallback call
  public static final String EXTRA_LANG = "lang";
  public static final String EXTRA_TITLE = "title";
  public static final String EXTRA_BODY = "body";
  public static final String EXTRA_SOUND = "sound";
  public static final String EXTRA_KEY = "key";
  public static final String EXTRA_TIME = "time";
  public static final String EXTRA_NOTIFY = "notify"; // post the alarm notification after speaking
  public static final String EXTRA_FIRED_AT = "firedAt";

  private static final String CHANNEL_ID = "oh_speak";
  private static final int FGS_ID = 43901;

  private TextToSpeech tts;
  private boolean ttsReady = false;
  private boolean finished = false;
  private String pendingPayload = null;
  private String lang = "en"; // v4.1: ENGLISH is the default call language
  private String speakEn = ""; // v4.1: English copy for the no-bn-voice fallback

  @Override
  public IBinder onBind(Intent intent) {
    return null;
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    try {
      final String speak = intent.getStringExtra(EXTRA_SPEAK);
      lang = intent.getStringExtra(EXTRA_LANG);
      if (lang == null || lang.isEmpty()) lang = "en"; // v4.1: default ENGLISH
      speakEn = intent.getStringExtra(EXTRA_SPEAK_EN);
      if (speakEn == null) speakEn = "";
      final String title = intent.getStringExtra(EXTRA_TITLE);
      final String body = intent.getStringExtra(EXTRA_BODY);
      final String sound = intent.getStringExtra(EXTRA_SOUND);
      final String key = intent.getStringExtra(EXTRA_KEY);
      final String time = intent.getStringExtra(EXTRA_TIME);
      final boolean notify = intent.getBooleanExtra(EXTRA_NOTIFY, false);
      final long firedAt = intent.getLongExtra(EXTRA_FIRED_AT, 0L);

      // v4.0: no startForeground — no notification of our own. The REAL
      // alarm notification is posted AFTER the voice finishes
      // (postAlarmNotification below).

      if (speak == null || speak.trim().isEmpty()) {
        if (notify) postAlarmNotification(title, body, sound, key, time, firedAt);
        stopSelfSafely();
        return START_NOT_STICKY;
      }

      // remember what to notify AFTER the voice finishes
      if (notify) {
        try {
          org.json.JSONObject o = new org.json.JSONObject();
          o.put("title", title);
          o.put("body", body);
          o.put("sound", sound);
          o.put("key", key);
          o.put("time", time);
          o.put("firedAt", firedAt);
          pendingPayload = o.toString();
        } catch (Exception ignored) {
          pendingPayload = null;
        }
      }

      tts = new TextToSpeech(getApplicationContext(), status -> {
        try {
          if (status == TextToSpeech.SUCCESS && tts != null) {
            ttsReady = true;
            configureVoiceAndSpeak(speak, speakEn);
          } else {
            // no TTS engine → go straight to the alarm sound
            ttsReady = false;
            onSpeakDone();
          }
        } catch (Exception e) {
          onSpeakDone();
        }
      });
      // hard safety: never stay alive longer than 45s
      new android.os.Handler(getMainLooper()).postDelayed(() -> onSpeakDone(), 45000);
      return START_NOT_STICKY;
    } catch (Exception e) {
      stopSelfSafely();
      return START_NOT_STICKY;
    }
  }

  private void configureVoiceAndSpeak(String speak, String speakEn) {
    try {
      // v4.1: the VOICE language. "en" (default) = the old English call
      // ("Sakib, it's your time to drink water…") — works on EVERY phone with
      // zero setup. "bn" = the optional Bangla call; when this phone has NO
      // Bangla TTS voice installed we fall back to the ENGLISH copy so the
      // call is never silent (owner round-16: "অনেকে বাংলা ভয়েসের সেটিং
      // করতে পারবে না — আগের ইংলিশটা থাকবে").
      String speakText = speak;
      String spokenTag = "en";
      if ("bn".equals(lang)) {
        int r = tts.setLanguage(new Locale("bn", "BD"));
        if (langBad(r)) r = tts.setLanguage(new Locale("bn", "IN"));
        if (langBad(r)) r = tts.setLanguage(new Locale("bn"));
        if (langBad(r)) {
          // NO Bangla voice on this phone → speak the ENGLISH copy instead
          setEnglishLocale();
          if (speakEn != null && !speakEn.trim().isEmpty()) speakText = speakEn;
        } else {
          spokenTag = "bn";
        }
      } else {
        setEnglishLocale();
      }
      // v3.3 GENDER: try to pick a female voice for girls / a male voice for
      // boys (owner: "মেয়ের নাম হলে একটা মেয়ে বলবে, ছেলের নাম হলে একটা ছেলে
      // বলবে"). Best-effort — Android's Voice API has no official gender field,
      // so we match engine voices whose name/features hint at the gender and
      // silently keep the default voice when the engine exposes none.
      try {
        applyGenderedVoice(spokenTag);
      } catch (Exception ignored) {
      }
      tts.setAudioAttributes(new AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_ALARM)
          .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
          .build());
      tts.setSpeechRate(0.95f);
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
        @Override
        public void onStart(String utteranceId) {
        }

        @Override
        public void onDone(String utteranceId) {
          onSpeakDone();
        }

        @Override
        public void onError(String utteranceId) {
          onSpeakDone();
        }
      });
      // v2.9.1 FIX: 4-arg speak() needs a Bundle, NOT a HashMap — javac
      // error "HashMap cannot be converted to Bundle" broke the whole APK build.
      tts.speak(speakText, TextToSpeech.QUEUE_FLUSH, null, "ohAlert");
      // if the engine never calls back (some OEMs), the voice still ends →
      // estimate the duration and continue
      long est = estimateSpeechMs(speakText);
      new android.os.Handler(getMainLooper()).postDelayed(() -> onSpeakDone(), est + 6000);
    } catch (Exception e) {
      onSpeakDone();
    }
  }

  private static boolean langBad(int r) {
    return r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED;
  }

  /** v4.1: the best English locale this engine has — en-US first, then en-IN
   *  (very common on South-Asian phones and it pronounces Bangladeshi names
   *  nicely), then en-GB, then the bare "en" tag. */
  private void setEnglishLocale() {
    int r = tts.setLanguage(new Locale("en", "US"));
    if (langBad(r)) r = tts.setLanguage(new Locale("en", "IN"));
    if (langBad(r)) r = tts.setLanguage(new Locale("en", "GB"));
    if (langBad(r)) tts.setLanguage(new Locale("en"));
  }

  private static long estimateSpeechMs(String text) {
    try {
      int words = text.trim().split("\\s+").length;
      return Math.min(20000, Math.max(3000, words * 420L));
    } catch (Exception e) {
      return 8000;
    }
  }

  /**
   * v3.3 GENDER-AWARE VOICE: try to switch to a female/male voice of the
   * given language. The app writes the user's gender via ExactAlarmPlugin
   * .setVoiceGender (SettingsTab effect). Android's Voice API has no
   * official gender, so we look for engine voices whose NAME or FEATURES
   * hint at the gender ("female"/"male", "f"/"m" word-bounded, some engines
   * expose it in getFeatures()). If nothing matches we keep the current
   * voice — the sentence still speaks in Bengali either way.
   */
  private void applyGenderedVoice(String langTag) {
    try {
      final String gender = ExactAlarmPlugin.storedVoiceGender(getApplicationContext());
      if (tts == null) return;
      // v4.0: plus a soft pitch shift — most engines expose NO gendered
      // Bangla voices, so this is what actually makes the difference
      // audible (male = slightly deeper, female = slightly brighter).
      try {
        tts.setPitch("male".equals(gender) ? 0.9f : 1.05f);
      } catch (Exception ignored) {
      }
      java.util.Set<Voice> voices;
      try {
        voices = tts.getVoices();
      } catch (Exception e) {
        return;
      }
      if (voices == null || voices.isEmpty()) return;
      final String want = "female".equals(gender) ? "female" : "male";
      final String other = "female".equals(want) ? "male" : "female";
      Voice best = null;
      for (Voice v : voices) {
        if (v == null || v.getLocale() == null) continue;
        if (!langTag.equalsIgnoreCase(v.getLocale().getLanguage())) continue;
        String name = (v.getName() == null ? "" : v.getName()).toLowerCase();
        StringBuilder feats = new StringBuilder();
        try {
          for (String f : v.getFeatures()) {
            if (f != null) feats.append(f.toLowerCase()).append(' ');
          }
        } catch (Exception ignored) {
        }
        String hay = name + " " + feats;
        if (hay.contains(want)) {
          // a voice that explicitly matches the wanted gender wins immediately
          if (!hay.contains(other) || best == null) {
            best = v;
            if (!hay.contains(other)) break; // clean match — stop searching
          }
        } else if (best == null && (name.startsWith("bn") || name.contains(langTag))) {
          // remember the first plain bn voice as a neutral fallback (already
          // the active language — setVoice below only fires on an explicit hit)
        }
      }
      if (best != null) {
        try {
          tts.setVoice(best);
        } catch (Exception ignored) {
        }
      }
    } catch (Exception ignored) {
    }
  }

  /** Voice finished (or failed) → post the real alarm notification, then die. */
  private synchronized void onSpeakDone() {
    if (finished) return;
    finished = true;
    try {
      if (pendingPayload != null) {
        org.json.JSONObject o = new org.json.JSONObject(pendingPayload);
        postAlarmNotification(
            o.optString("title", "Our Habit"),
            o.optString("body", ""),
            o.optString("sound", "alarm.wav"),
            o.optString("key", ""),
            o.optString("time", ""),
            o.optLong("firedAt", 0L));
      }
    } catch (Exception ignored) {
    }
    stopSelfSafely();
  }

  private void postAlarmNotification(String title, String body, String sound, String key, String time, long firedAt) {
    try {
      Context ctx = getApplicationContext();
      // remember the launch payload → the WebView opens the right overlay
      if (key != null && !key.isEmpty()) {
        try {
          org.json.JSONObject launch = new org.json.JSONObject();
          launch.put("key", key);
          launch.put("title", title);
          launch.put("body", body);
          launch.put("sound", sound);
          launch.put("time", time);
          launch.put("firedAt", firedAt > 0 ? firedAt : System.currentTimeMillis());
          SharedPreferences sp = ExactAlarmPlugin.prefs(ctx);
          sp.edit().putString("launch_payload", launch.toString()).apply();
        } catch (Exception ignored) {
        }
      }
      ExactAlarmPlugin.ensureChannel(ctx, sound == null || sound.isEmpty() ? "alarm.wav" : sound);
      String channelId = ExactAlarmPlugin.channelIdFor(sound == null || sound.isEmpty() ? "alarm.wav" : sound);

      PendingIntent content = ExactAlarmPlugin.launchPendingIntent(ctx, 3);
      int notifId = (int) (System.currentTimeMillis() % 2100000000);

      NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, channelId)
          .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
          .setContentTitle(title == null || title.isEmpty() ? "Our Habit" : title)
          .setContentText(body == null ? "" : body)
          .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "" : body))
          .setPriority(NotificationCompat.PRIORITY_MAX)
          .setCategory(NotificationCompat.CATEGORY_ALARM)
          .setAutoCancel(true)
          .setContentIntent(content)
          .setVibrate(new long[]{0, 400, 250, 400, 250, 600});

      NotificationManagerCompat nm = NotificationManagerCompat.from(ctx);
      boolean allowed = true;
      try {
        allowed = nm.areNotificationsEnabled();
      } catch (Exception ignored) {
      }
      if (allowed) {
        try {
          nm.notify(notifId, b.build());
        } catch (SecurityException ignored) {
        }
      }
    } catch (Exception ignored) {
    }
  }

  private void stopSelfSafely() {
    try {
      if (tts != null) {
        try {
          tts.stop();
        } catch (Exception ignored) {
        }
        try {
          tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
      }
    } catch (Exception ignored) {
    }
    stopSelf();
  }

  @Override
  public void onDestroy() {
    try {
      if (tts != null) tts.shutdown();
    } catch (Exception ignored) {
    }
    super.onDestroy();
  }

  // ---------------- entry points ----------------

  /** Speak + then post the alarm notification (used by AlarmFireReceiver). */
  static void startForAlarm(Context ctx, String speak, String lang, String speakEn, String title, String body,
                            String sound, String key, String time) {
    try {
      Intent i = new Intent(ctx, AlarmSpeakService.class);
      i.putExtra(EXTRA_SPEAK, speak);
      i.putExtra(EXTRA_LANG, lang);
      i.putExtra(EXTRA_SPEAK_EN, speakEn == null ? "" : speakEn);
      i.putExtra(EXTRA_TITLE, title);
      i.putExtra(EXTRA_BODY, body);
      i.putExtra(EXTRA_SOUND, sound);
      i.putExtra(EXTRA_KEY, key);
      i.putExtra(EXTRA_TIME, time);
      i.putExtra(EXTRA_NOTIFY, true);
      i.putExtra(EXTRA_FIRED_AT, System.currentTimeMillis());
      // v4.0: plain startService — no foreground service, no notification of
      // our own. From AlarmFireReceiver.onReceive / the open app (both are
      // allowed contexts); if Android still refuses, the catch below posts a
      // plain notification so the alarm is never lost.
      ctx.startService(i);
    } catch (Exception ignored) {
      // fall back to a plain notification so the alarm is never lost
      try {
        ExactAlarmPlugin.ensureChannel(ctx, sound);
        android.app.PendingIntent pi = ExactAlarmPlugin.launchPendingIntent(ctx, 3);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, ExactAlarmPlugin.channelIdFor(sound))
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi);
        NotificationManagerCompat.from(ctx).notify((int) (System.currentTimeMillis() % 2100000000), b.build());
      } catch (Exception ignored2) {
      }
    }
  }

  /** Speak only — no notification (in-app / Reels-limit warnings). */
  static void startSpeakOnly(Context ctx, String speak, String lang, String speakEn) {
    try {
      Intent i = new Intent(ctx, AlarmSpeakService.class);
      i.putExtra(EXTRA_SPEAK, speak);
      i.putExtra(EXTRA_LANG, lang);
      i.putExtra(EXTRA_SPEAK_EN, speakEn == null ? "" : speakEn);
      i.putExtra(EXTRA_NOTIFY, false);
      // v4.0: plain startService — no foreground service, no notification.
      ctx.startService(i);
    } catch (Exception ignored) {
    }
  }
}
